export const ADDFILM="addfilm"
export const EDITFILM="editfilm"
export const DELETEFILM="deletefilm"
export const GETFILMS="getfilms"